package com.br.model.pessoa;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class PessoaResponse {
	
	private long id;
	
    private String nome;

    private String email;

    private String telefone;

	

}
