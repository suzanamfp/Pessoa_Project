package com.br.model.pessoa;

import lombok.Data;

@Data
public class PessoaRequest {
	
    private String nome;

    private String email;

    private String telefone;

}
